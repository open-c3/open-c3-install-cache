+{
   locale_version => 1.14,
   entry => <<'ENTRY', # for DUCET v7.0.0
0149      ; [.1A7D.0020.0009] # LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
ENTRY
};
