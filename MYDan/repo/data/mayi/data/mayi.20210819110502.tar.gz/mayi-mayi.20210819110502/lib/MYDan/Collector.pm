package MYDan::Collector;

use strict;
use warnings;

=head1 NAME

collecotr - A client for collector data

=cut

1;
