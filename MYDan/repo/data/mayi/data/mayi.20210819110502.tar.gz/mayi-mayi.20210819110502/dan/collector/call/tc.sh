#!/bin/bash

echo 'CALLT A B C'
echo 'V1 1 2 3'
echo 'V2 2 3 4'
